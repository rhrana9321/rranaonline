#
# TABLE STRUCTURE FOR: account_head_table
#

DROP TABLE IF EXISTS `account_head_table`;

CREATE TABLE `account_head_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (1, 'Sawon', 'stuff');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (2, 'Muktar', 'Stuff');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (3, 'Badhol', 'Sekher gao');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (4, 'Karent bil', 'office');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (5, 'Office Vara', 'woner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (6, 'Bipul', 'tetutola');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (7, 'Jakir', 'jamaldi');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (8, 'Bashar membar', 'mohammadpure');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (9, 'Puji', '');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (10, 'customers due bill', '');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (11, 'Auto vara', 'potidin');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (12, 'Dairy', 'office jonn');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (13, 'Chata', 'office jonn');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (14, 'Bag', 'officer jonn');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (15, 'Dhaka vara', 'mal kina');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (16, 'সার্ভিসিং মালামাল', 'Old product');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (17, 'Sekh monir', 'patner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (18, 'Gaffar mama', 'patner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (19, 'Samol vai', 'patner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (20, 'Afjal', 'patner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (21, 'Razib Hossain Rana', 'patner');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (22, 'মালামাল', 'office/নেট');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (23, 'সার্ভিস চার্জ', 'নেট');
INSERT INTO `account_head_table` (`id`, `name`, `details`) VALUES (24, 'Bill', 'net');


#
# TABLE STRUCTURE FOR: account_statement_table
#

DROP TABLE IF EXISTS `account_statement_table`;

CREATE TABLE `account_statement_table` (
  `acc_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_date` date NOT NULL,
  `particular` longtext NOT NULL,
  `client` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `expence_id` int(11) NOT NULL,
  `others_income` int(11) NOT NULL,
  `credit` double NOT NULL,
  `debit` double NOT NULL,
  `balance` double NOT NULL,
  `month_name` int(11) NOT NULL,
  `history_record` varchar(250) NOT NULL,
  PRIMARY KEY (`acc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (2, '2020-06-16', 'June Months Connection charge payment of Simran', 0, 0, 0, 0, 0, '1800', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (6, '2020-06-01', 'deloyar', 0, 0, 0, 0, 2, '1000', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (7, '2020-06-01', 'total bill', 0, 0, 0, 0, 3, '4400', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (9, '2020-06-16', 'June Months Connection charge payment of Jinnat vai', 0, 0, 0, 0, 0, '1000', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (10, '2020-06-07', 'total bill-net', 0, 0, 0, 0, 5, '3600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (11, '2020-06-07', 'tisha-cable bill', 0, 0, 0, 0, 6, '600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (12, '2020-06-09', 'total bill', 0, 0, 0, 0, 7, '1100', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (13, '2020-06-09', 'sabbir-cable bill net', 0, 0, 0, 0, 8, '600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (14, '2020-06-11', 'total bill', 0, 0, 0, 0, 9, '900', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (15, '2020-06-12', 'total bill', 0, 0, 0, 0, 10, '2400', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (16, '2020-06-09', 'net/afol sopon', 0, 0, 0, 0, 11, '400', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (17, '2020-06-14', 'total bill', 0, 0, 0, 0, 12, '600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (18, '2020-06-15', 'total bill', 0, 0, 0, 0, 13, '1800', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (19, '2020-06-17', 'total bill', 0, 0, 0, 0, 14, '3400', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (20, '2020-06-18', 'total bill', 0, 0, 0, 0, 15, '1100', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (22, '2020-06-20', 'total bill-d bank/kalam', 0, 0, 0, 0, 17, '1500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (23, '2020-06-21', 'June Months connecting charge of  Taijul/sahajala', 76, 76, 0, 0, 0, '200', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (24, '2020-06-21', 'June Months Bill collection of Simran', 41, 0, 6, 0, 0, '1000', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (25, '2020-06-07', 'net malamal', 0, 0, 0, 3, 0, '0', '18980', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (27, '2020-06-21', 'gaffar/sahin', 0, 0, 0, 0, 18, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (29, '2020-06-22', 'kamrul cable ', 0, 0, 0, 0, 20, '1500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (30, '2020-06-21', 'choyon-7600-anik-7000', 0, 0, 0, 0, 21, '14600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (31, '2020-06-21', 'anik/choyon net', 0, 0, 0, 4, 0, '0', '12460', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (32, '2020-06-21', 'router sell,', 0, 0, 0, 5, 5, '0', '7250', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (33, '2020-06-21', 'razib', 0, 0, 0, 6, 0, '0', '500', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (34, '2020-06-27', 'net bill-june', 0, 0, 0, 7, 0, '0', '20000', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (35, '2020-06-22', 'June Months Bill collection of Tamim', 36, 0, 8, 0, 0, '600', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (36, '2020-06-22', 'June Months Bill collection of Tamim', 36, 0, 9, 0, 0, '400', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (37, '2020-06-21', 'June Months Bill collection of Taijul/sahajala', 76, 0, 10, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (38, '2020-06-21', 'June Months Bill collection of Halim vai', 19, 0, 11, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (39, '2020-06-21', 'June Months Bill collection of Halim vai', 19, 0, 12, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (40, '2020-06-21', 'June Months Bill collection of Rasel', 14, 0, 13, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (41, '2020-06-21', 'June Months Bill collection of Kaium', 60, 0, 14, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (42, '2020-06-21', 'June Months Bill collection of Nadim', 62, 0, 15, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (44, '2020-06-29', 'rakib-Febr-may-june', 0, 0, 0, 0, 22, '2000', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (45, '2020-06-29', 'June Months Bill collection of Rakib', 26, 0, 17, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (46, '2020-06-30', 'June Months Bill collection of Aowlad', 16, 0, 18, 0, 0, '1000', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (48, '2020-06-30', 'June Months Opeaning amount of  Mobarok', 78, 78, 0, 0, 0, '500', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (49, '2020-06-30', 'June Months connecting charge of  Mobarok', 78, 78, 0, 0, 0, '800', '0', '0', 6, '');
INSERT INTO `account_statement_table` (`acc_id`, `c_date`, `particular`, `client`, `customer_id`, `payment_id`, `expence_id`, `others_income`, `credit`, `debit`, `balance`, `month_name`, `history_record`) VALUES (50, '2020-06-30', 'June Months Opeaning amount of Anish', 79, 79, 0, 0, 0, '500', '0', '0', 6, '');


#
# TABLE STRUCTURE FOR: add_complain_table
#

DROP TABLE IF EXISTS `add_complain_table`;

CREATE TABLE `add_complain_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `customer_id` longtext NOT NULL,
  `template` longtext NOT NULL,
  `details` longtext NOT NULL,
  `note` longtext NOT NULL,
  `employee` longtext NOT NULL,
  `sms_check` int(11) NOT NULL,
  `complain_date` varchar(100) NOT NULL,
  `complain_time` varchar(100) NOT NULL,
  `customer_address` longtext NOT NULL,
  `type` varchar(100) NOT NULL,
  `customer_mobile` longtext NOT NULL,
  `solve_date` varchar(100) NOT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: add_customer_sms_table
#

DROP TABLE IF EXISTS `add_customer_sms_table`;

CREATE TABLE `add_customer_sms_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `header_sms` longtext NOT NULL,
  `sms_details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `add_customer_sms_table` (`id`, `header_sms`, `sms_details`) VALUES (1, 'আসসালামুয়ালাইকুম', 'দয়া করে আপনার বিলগুলো পরিশোধ করুন');


#
# TABLE STRUCTURE FOR: admin_manage
#

DROP TABLE IF EXISTS `admin_manage`;

CREATE TABLE `admin_manage` (
  `id` int(11) NOT NULL,
  `full_name` varchar(40) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `email_address` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `present_address` varchar(100) NOT NULL,
  `permanent_address` varchar(150) NOT NULL,
  `select_gender` varchar(23) NOT NULL,
  `national_id_no` varchar(50) NOT NULL,
  `status` varchar(12) NOT NULL,
  `image` varchar(44) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admin_manage` (`id`, `full_name`, `user_name`, `email_address`, `password`, `mobile_no`, `present_address`, `permanent_address`, `select_gender`, `national_id_no`, `status`, `image`) VALUES (6, 'md sawkat hossain', 'admin', 'mdsawkathossain1@gmail.co', 'admin', '01854278070', 'rampura,dhaka', 'shibchar,madaripur', 'Male', '3.23232e15', 'Active', '1437724349.18.56.jpg');
INSERT INTO `admin_manage` (`id`, `full_name`, `user_name`, `email_address`, `password`, `mobile_no`, `present_address`, `permanent_address`, `select_gender`, `national_id_no`, `status`, `image`) VALUES (7, 'hridoy khan', 'busyboy63', 'hridoykhan12@gmail.com', 'admin', '01956985521', 'khilkhet,dhaka', 'Shibchar,madaripur', 'Male', '5.64656e15', 'Inactive', '1437819313.jpg');


#
# TABLE STRUCTURE FOR: agrim_manage_table
#

DROP TABLE IF EXISTS `agrim_manage_table`;

CREATE TABLE `agrim_manage_table` (
  `agrim_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `email` longtext NOT NULL,
  `mobile` varchar(22) CHARACTER SET utf8 NOT NULL,
  `address` longtext CHARACTER SET utf8 NOT NULL,
  `datetime` varchar(200) CHARACTER SET utf8 NOT NULL,
  `Pur_ager_sabeg_taka` double NOT NULL,
  `cus_due_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `agrim_manage_table` (`agrim_id`, `name`, `email`, `mobile`, `address`, `datetime`, `Pur_ager_sabeg_taka`, `cus_due_amount`) VALUES (1, 'Saiful-agrim', '', '01853951775', 'Dhaka', '', '0', '0');
INSERT INTO `agrim_manage_table` (`agrim_id`, `name`, `email`, `mobile`, `address`, `datetime`, `Pur_ager_sabeg_taka`, `cus_due_amount`) VALUES (3, 'lal-agrim', '', '01971321922', '32 dhaka', 'August 28-2019/12:53:44am: ', '0', '0');
INSERT INTO `agrim_manage_table` (`agrim_id`, `name`, `email`, `mobile`, `address`, `datetime`, `Pur_ager_sabeg_taka`, `cus_due_amount`) VALUES (4, 'a-agrim', '', '01853951775', 'Dhaka', '', '0', '0');


#
# TABLE STRUCTURE FOR: basic_manage
#

DROP TABLE IF EXISTS `basic_manage`;

CREATE TABLE `basic_manage` (
  `id` int(50) NOT NULL,
  `page_title` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `web_logo` varchar(50) NOT NULL,
  `status` varchar(52) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(45) NOT NULL,
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1rb6cj1luhveriv93brmu8e86maab9bp', '::1', '0000-00-00 00:00:00', '__ci_last_regenerate|i:1518414130;invalidUser|s:0:\"\";userid|s:1:\"6\";email|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93bnfjpnjesj42h4rv14j89m8tj1fdle', '::1', '0000-00-00 00:00:00', '__ci_last_regenerate|i:1518414478;invalidUser|s:0:\"\";userid|s:1:\"6\";email|s:5:\"admin\";mg|s:10:\"Hello wold\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ebk0h80cd0g5duejvq3h6vb9dm7865g', '::1', '0000-00-00 00:00:00', '__ci_last_regenerate|i:1518415919;invalidUser|s:0:\"\";userid|s:1:\"6\";email|s:5:\"admin\";mg|s:10:\"Hello wold\";');


#
# TABLE STRUCTURE FOR: complain_template_table
#

DROP TABLE IF EXISTS `complain_template_table`;

CREATE TABLE `complain_template_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `comments` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (1, 'a');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (2, 'b');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (3, 'c');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (4, 'd');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (5, 'e');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (6, 'uhuhyu');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (7, 'kjmij');
INSERT INTO `complain_template_table` (`id`, `comments`) VALUES (8, 'knyghb bsd ');


#
# TABLE STRUCTURE FOR: connecting_charge_report_table
#

DROP TABLE IF EXISTS `connecting_charge_report_table`;

CREATE TABLE `connecting_charge_report_table` (
  `connecting_report_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` double NOT NULL,
  `cdate_time` varchar(1000) NOT NULL,
  `monthly_name` int(11) NOT NULL,
  `yearly_name` int(11) NOT NULL,
  PRIMARY KEY (`connecting_report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (1, 41, '2020-06-16', '1800', '25/06/2020 11:56:34 am', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (2, 74, '2020-06-25', '0', '25/06/2020 01:28:45 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (3, 66, '2020-06-16', '1000', '07/06/2020 09:03:06 am', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (4, 75, '2020-06-27', '0', '27/06/2020 07:35:19 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (5, 76, '2020-06-21', '200', '21/06/2020 08:57:57 am', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (6, 77, '2020-06-30', '800', '30/06/2020 09:15:44 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (7, 78, '2020-06-30', '800', '30/06/2020 09:18:18 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (8, 79, '2020-06-30', '500', '30/06/2020 09:23:23 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (9, 80, '2020-06-30', '0', '30/06/2020 09:29:30 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (10, 81, '2020-06-30', '0', '30/06/2020 09:31:02 pm', 6, 2020);
INSERT INTO `connecting_charge_report_table` (`connecting_report_id`, `customer_id`, `payment_date`, `amount`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (11, 82, '2020-07-04', '0', '04/07/2020 06:03:05 pm', 7, 2020);


#
# TABLE STRUCTURE FOR: customer_table
#

DROP TABLE IF EXISTS `customer_table`;

CREATE TABLE `customer_table` (
  `custo_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id_create` longtext NOT NULL,
  `name` varchar(100) NOT NULL,
  `previus_months_due` double NOT NULL,
  `running_bill` double NOT NULL,
  `mobile` varchar(22) NOT NULL,
  `regularmobile` varchar(22) NOT NULL,
  `email` longtext NOT NULL,
  `national_id` longtext NOT NULL,
  `details` longtext NOT NULL,
  `zone` int(11) NOT NULL,
  `opening_amount` double DEFAULT '0',
  `running_month_due_amount` double DEFAULT '0',
  `connect_charge` double DEFAULT '0',
  `connection_charge_due_amount` double DEFAULT '0',
  `con_date` date NOT NULL,
  `package` int(11) NOT NULL,
  `Clint_IP` longtext NOT NULL,
  `taka` double NOT NULL,
  `bill_date` double NOT NULL,
  `status` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `logo_image` longtext NOT NULL,
  `previus_due_note` longtext CHARACTER SET utf8 NOT NULL,
  `village` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`custo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4;

INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (1, '1001', 'md ador', '1600', '600', '01305931399', '', '', '', 'Mohammadpure', 1, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.ador', '600', '5', 1, '', '', 'april-may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (2, '1002', 'Sahadat', '1600', '600', '01880975437', '', '', '', 'Mohammadpure', 1, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.sahadat', '600', '5', 1, '', '', 'april-may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (3, '1003', 'Hridoy', '600', '600', '01956000478', '', '', '', 'Mohammadpure', 1, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.siyab', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (4, '1004', 'razibrana', '600', '600', '01913193557', '', '', '', 'Mohammadpure', 21, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.rana', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (5, '1005', 'Kamrul', '600', '600', '01991446223', '', '', '', 'Bazar, Mohammadpure', 22, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.dihamoni', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (6, '1006', 'Siyam', '600', '600', '01706319558', '', '', '', 'Bazar, Mohammadpure', 22, '0', NULL, '0', NULL, '2020-06-23', 1, 'lc.siyam', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (7, '1007', 'Tisha', '1200', '600', '01884014278', '', '', '', 'Bazar, Mohammadpure', 22, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.tisha', '600', '5', 1, '', '', 'may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (8, '1008', 'Kalam', '600', '600', '01878801167', '', '', '', 'Bazar, Mohammadpure', 22, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.kalam', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (9, '1009', 'Sekandar', '2400', '600', '01642302578', '', '', '', 'Bazar, Mohammadpure', 22, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.sikandar', '600', '5', 1, '', '', 'march-may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (10, '1010', 'Liton', '1800', '600', '01820507015', '', '', '', 'Stand, Mohammadpure', 2, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.liton', '600', '5', 1, '', '', 'april-may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (11, '1011', 'Kawsar vai', '1800', '600', '01718881703', '', '', '', 'Stand, Mohammadpure', 2, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.kawsar', '600', '5', 1, '', '', 'april-may-2020', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (12, '1012', 'D-Bank', '600', '600', '', '', '', '', 'Stand, Mohammadpure', 2, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rjkalam', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (13, '1013', 'Delowar', '600', '600', '01858617424', '', '', '', 'Stand, Mohammadpure', 2, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.hannan', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (14, '1014', 'Rasel', '1900', '600', '01935641775', '', '', '', 'Noya Mohammadpure', 19, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rasel', '600', '5', 1, '', '', 'march-may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (15, '1015', 'Azizul', '1200', '600', '01995531504', '', '', '', 'Noya Mohammadpure', 19, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.azizul', '600', '5', 1, '', '', 'may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (16, '1016', 'Aowlad', '800', '600', '01818014729', '', '', '', 'Noya Mohammadpure', 19, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.aowlad', '600', '5', 1, '', '', 'april-may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (17, '1017', 'Sahin/gaffar', '1800', '600', '01939010766', '', '', '', 'Noya Mohammadpure', 19, '0', NULL, '0', '200', '2020-06-01', 1, 'lc.gaffar', '600', '5', 1, '', '', 'april-may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (18, '1018', 'Monirul vai', '600', '600', '01911202846', '', '', '', 'Noya Mohammadpure', 20, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.monirul', '600', '5', 1, '', '', '', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (19, '1019', 'Halim vai', '100', '500', '01986422328', '', '', '', 'Noya Mohammadpure', 20, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.halim', '500', '5', 1, '', '', 'may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (20, '1020', 'Nurul', '1400', '600', '00', '', '', '', 'Noya Mohammadpure', 20, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.nurul', '600', '5', 1, '', '', 'may-2020', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (21, '1021', 'Rakib', '600', '600', '01871095298', '', '', '', 'Noya Mohammadpure', 20, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.mamun', '600', '5', 1, '', '', '', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (22, '1022', 'Tarek vai', '600', '600', '00', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.tarek', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (23, '1023', 'Afjal vai/sopon', '600', '600', '01877174000', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.afjol', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (24, '1024', 'Ripon vai', '600', '600', '01866638289', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.ripon', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (25, '1025', 'Milon vai', '600', '600', '01822244430', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.milon', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (26, '1026', 'Rakib', '0', '500', '01877642115', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rakib', '500', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (27, '1027', 'Dr.tarek', '600', '600', '01730186675', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.dactar', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (28, '1028', 'Saiful', '600', '600', '', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.saiful', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (29, '1029', 'Arif', '1200', '600', '01922676763', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.arif', '600', '5', 1, '', '', 'may-2020', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (30, '1030', 'Mucha', '600', '600', '01879886264', '', '', '', 'stand, kandargao ', 3, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.musa', '600', '5', 1, '', '', '', 'Noya kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (31, '1031', 'Masud vai', '600', '600', '', '', '', '', 'Bazar, Luterchar', 8, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.masud', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (32, '1032', 'Uonion office', '1700', '1000', '', '', '', '', 'Bazar, Luterchar', 8, '0', NULL, '0', NULL, '2020-06-01', 2, 'lc.lutercharup', '1000', '5', 1, '', '', 'may-2020', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (33, '1033', 'Shamol vai', '600', '600', '01922616710', '', '', '', 'Bazar, Luterchar', 21, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.shamol', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (34, '1034', 'Uzzol vai', '600', '600', '', '', '', '', 'Bazar, Luterchar', 8, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.tawfin', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (35, '1035', 'Mohsin/sekh monir', '600', '600', '', '', '', '', 'orola khamba, Luterchar', 21, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.mohsin', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (36, '1036', 'Tamim', '200', '600', '01758985320', '', '', '', 'orola khamba, Luterchar', 9, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.tamim', '600', '5', 1, '', '', 'may-2020', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (37, '1037', 'Nahid', '600', '600', '01837116987', '', '', '', 'orola khamba, Luterchar', 9, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.nahid', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (38, '1038', 'Mahin', '600', '600', '01852060592', '', '', '', 'orola khamba, Luterchar', 9, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.mahin', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (39, '1039', 'Sumon', '600', '600', '01784590231', '', '', '', 'orola khamba, Luterchar', 9, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.elma', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (40, '1040', 'Rayhan', '1200', '600', '01782684712', '', '', '', 'orola khamba, Luterchar', 9, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rayhan', '600', '5', 1, '', '', 'may-2020', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (41, '1041', 'Simran', '0', '1000', '', '', '', '', 'high school, Luterchar', 16, '0', '0', NULL, '0', '2020-06-01', 2, 'lc.simran', '1000', '5', 1, '', '', '', 'Dhori luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (42, '1042', 'High school', '3000', '1000', '', '', '', '', 'high school, Luterchar', 16, '0', NULL, '0', NULL, '2020-06-01', 2, 'lc.highschool', '1000', '5', 1, '', '', 'april-may-2020', 'Dhori luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (43, '1043', 'Mahabub sikdar', '600', '600', '', '', '', '', 'chayarman bari, Luterchar', 21, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.delowr', '600', '5', 1, '', '', '', 'Dhori luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (44, '1044', 'Hridoy', '1200', '600', '01875394730', '', '', '', 'chayarman bari, Luterchar', 17, '0', NULL, '0', '750', '2020-06-01', 1, 'lc.ridoy1', '600', '5', 1, '', '', 'may-2020', 'Dhori luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (45, '1045', 'Chayon', '600', '600', '01677047764', '', '', '', 'chayarman bari, Luterchar', 17, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.chyon', '600', '5', 1, '', '', '', 'Dhori luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (46, '1046', 'Chayarman', '600', '600', '', '', '', '', 'chayarman bari, Luterchar', 17, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.chayarman', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (47, '1047', 'Habib sikdar', '600', '600', '', '', '', '', 'chayarman bari, Luterchar', 17, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (48, '1048', 'Helal sikdar', '600', '600', '', '', '', '', 'chayarman bari, Luterchar', 17, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.sikdar', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (49, '1049', 'Monir', '600', '600', '01811289352', '', '', '', 'emran bari, kandargao', 5, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.monir', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (50, '1050', 'Jubayer', '600', '600', '0193266354', '', '', '', 'emran bari, kandargao', 5, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.jubayer', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (51, '1051', 'Masum hujur', '600', '600', '', '', '', '', 'emran bari, kandargao', 5, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.masum', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (52, '1052', 'Rony/mazarul', '600', '600', '01874505031', '', '', '', 'arif bari, kandargao', 6, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.muzzamel', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (53, '1053', 'Khokon vai', '600', '600', '01956870314', '', '', '', 'arif bari, kandargao', 6, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.khokon', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (54, '1054', 'Moyna apa', '600', '600', '', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.moyna', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (55, '1055', 'Kamrul hujur', '3000', '600', '01643352930', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.kamrul', '600', '5', 1, '', '', 'Feb-may-2020', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (56, '1056', 'Sabbir', '600', '600', '', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.sakil', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (57, '1057', 'Simul', '600', '600', '01955920883', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.simul', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (58, '1058', 'Raziya', '600', '600', '', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.hannan', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (59, '1059', 'Jony/mithu', '1500', '1000', '', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 2, 'lc.joni', '1000', '5', 1, '', '', 'june', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (60, '1060', 'Kaium', '0', '500', '', '', '', '', 'mosjid samne, kandargao', 7, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.kaium', '500', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (61, '1061', 'Rubel vai', '600', '600', '01845141450', '', '', '', 'Rubel bari, Luterchar', 10, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rubel', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (62, '1062', 'Nadim', '0', '500', '01822645561', '', '', '', 'Rubel bari, Luterchar', 10, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.nadim', '500', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (63, '1063', 'Nijamuddin', '600', '600', '01874362992', '', '', '', 'Rubel bari, Luterchar', 10, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.nijamuddin', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (64, '1064', 'Masud', '600', '600', '01843758897', '', '', '', 'Rubel bari, Luterchar', 10, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.masud1', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (65, '1065', 'Nazrul driver', '1800', '600', '01819099126', '', '', '', 'jakariya bari, Luterchar', 11, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.nazrul', '600', '5', 1, '', '', 'april-may-2020', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (66, '1066', 'Jinnat vai', '600', '600', '01956753926', '', '', '', 'jakariya bari, Luterchar', 11, '0', '0', '0', '0', '2020-06-01', 1, 'lc.jinnat', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (67, '1067', 'Muzammel membar', '600', '600', '', '', '', '', 'jakariya bari, Luterchar', 11, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.rimon', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (68, '1068', 'Gaffar mama', '600', '600', '01740893957', '', '', '', 'Gaffar bari, Luterchar', 14, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.mahi', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (69, '1069', 'Eyasin', '600', '600', '01788450840', '', '', '', 'Gaffar bari, Luterchar', 14, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.eyasin', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (70, '1070', 'Sahalom bai', '600', '600', '01870234072', '', '', '', 'sahalom bari, Luterchar', 21, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.sahalom', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (71, '1071', 'Aklima', '600', '600', '01879701432', '', '', '', 'sahalom bari, Luterchar', 15, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.akib', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (72, '1072', 'Foysal', '600', '600', '01826183406', '', '', '', 'sahalom bari, Luterchar', 15, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.foysal', '600', '5', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (73, '1073', 'Office', '600', '600', '01913193557', '', '', '', 'Office', 22, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.office', '600', '5', 1, '', '', '', 'Mohammadpur');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (75, '1074', 'Saown', '600', '600', '01683956850', '', '', '', 'kandargao', 21, '0', NULL, '0', NULL, '2020-06-01', 1, 'lc.gaffar2', '600', '5', 1, '', '', '', 'Kandargao');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (76, '1075', 'Taijul/sahajala', '0', '500', '', '', '', '', 'Noya Mohammadpure', 20, '0', NULL, '200', NULL, '2020-06-21', 1, 'lc.office', '500', '5', 1, '', '', '', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (78, '1076', 'Mobarok', '500', '500', '01726522570', '', '', '', 'rubel bari luterchar', 10, '500', NULL, '800', NULL, '2020-06-30', 1, 'lc.roton', '500', '10', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (79, '1077', 'Anish', '500', '500', '', '', '', '', 'Noya mohammadpure', 20, '0', NULL, '500', NULL, '2020-06-30', 1, 'lc.anish', '500', '10', 1, '', '', '', 'Noya Mohammadpure');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (80, '1078', 'Choyon', '1000', '1000', '01677047764', '', '', '', 'cheyarman bari luterchar', 16, '0', NULL, '0', NULL, '2020-06-30', 2, 'lc.choyon2', '1000', '10', 1, '', '', '', 'Luterchar');
INSERT INTO `customer_table` (`custo_id`, `customer_id_create`, `name`, `previus_months_due`, `running_bill`, `mobile`, `regularmobile`, `email`, `national_id`, `details`, `zone`, `opening_amount`, `running_month_due_amount`, `connect_charge`, `connection_charge_due_amount`, `con_date`, `package`, `Clint_IP`, `taka`, `bill_date`, `status`, `remarks`, `logo_image`, `previus_due_note`, `village`) VALUES (81, '1079', 'Anik sikdar', '1000', '1000', '01676151810', '', '', '', 'cheyarman bari luterchar', 17, '0', '2000', '0', '600', '2020-06-30', 2, 'lc.anik', '1000', '10', 1, '', '', '', 'Luterchar');


#
# TABLE STRUCTURE FOR: due_customer_sms_table
#

DROP TABLE IF EXISTS `due_customer_sms_table`;

CREATE TABLE `due_customer_sms_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `header_sms` longtext NOT NULL,
  `sms_details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_table
#

DROP TABLE IF EXISTS `employee_table`;

CREATE TABLE `employee_table` (
  `auto_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(22) NOT NULL,
  `regularmobile` varchar(22) NOT NULL,
  `email` longtext NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  `national_id` longtext NOT NULL,
  `con_date` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `details` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `logo_image` longtext NOT NULL,
  PRIMARY KEY (`auto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (5, 1001, 'Razib Hossain Rana', '01913193557', '01617720190', 'rhrana11@gmail.com', '', '3423432', '01-12-2013', 'MD/CEO', 'Mohammodpur', '', '1589776928.jpg');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (6, 1002, 'Gaffar', '01922328071', 'dgfhdfg', 'sss@gmail.com', '', '3423432', '12-05-2020', 'yhjyh', 'ghgfh', '', '');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (7, 1003, 'Sekh Monir', '01922328071', '01917720130', 'rhrana12@gmail.com', '', '3423432', '20-05-2020', 'rrt', 'yjhyhu', '', '');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (8, 1004, 'Samol ', '01922328071', '01917720130', 'rhrana12@gmail.com', '', '3423432', '27-05-2020', 'tyhy', 'retre', '', '');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (9, 1005, 'afjal', '01922328071', '01917720130', 'demo@easyispbilling.com', '', '3423432', '02-06-2020', 'tyhy', 'retgret', '', '');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (10, 1006, 'Moktar', '01922328071', '01917720130', 'demo@easyispbilling.com', '', '3423432', '19-05-2020', 'suparvaiser', 'grtyrtey', '', '1589777177.jpg');
INSERT INTO `employee_table` (`auto_id`, `employee_id`, `name`, `mobile`, `regularmobile`, `email`, `blood_group`, `national_id`, `con_date`, `designation`, `details`, `remarks`, `logo_image`) VALUES (11, 1007, 'Sawon', '01913193557', '01917720130', 'rhrana12@gmail.com', '', '3423432', '19-05-2020', 'junior Technical Support Execu', '', '', '1590475027.jpg');


#
# TABLE STRUCTURE FOR: expense_table
#

DROP TABLE IF EXISTS `expense_table`;

CREATE TABLE `expense_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `header_name` int(11) NOT NULL,
  `amount` double NOT NULL,
  `details` longtext NOT NULL,
  `cdate` date NOT NULL,
  `last_update` date NOT NULL,
  `month_name` int(11) NOT NULL,
  `year_name` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `expense_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `month_name`, `year_name`) VALUES (3, 22, '18980', 'net malamal', '2020-06-07', '2020-06-07', 6, 2020);
INSERT INTO `expense_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `month_name`, `year_name`) VALUES (4, 22, '12460', 'anik/choyon net', '2020-06-21', '2020-06-21', 6, 2020);
INSERT INTO `expense_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `month_name`, `year_name`) VALUES (5, 22, '7250', 'router sell,', '2020-06-21', '2020-06-21', 6, 2020);
INSERT INTO `expense_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `month_name`, `year_name`) VALUES (6, 15, '500', 'razib', '2020-06-21', '2020-06-21', 6, 2020);
INSERT INTO `expense_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `month_name`, `year_name`) VALUES (7, 7, '20000', 'net bill-june', '2020-06-27', '2020-06-27', 6, 2020);


#
# TABLE STRUCTURE FOR: inactive_customer_sms_table
#

DROP TABLE IF EXISTS `inactive_customer_sms_table`;

CREATE TABLE `inactive_customer_sms_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `sms_details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `inactive_customer_sms_table` (`id`, `sms_details`) VALUES (1, 'hlw world');


#
# TABLE STRUCTURE FOR: index_email
#

DROP TABLE IF EXISTS `index_email`;

CREATE TABLE `index_email` (
  `id` int(11) NOT NULL,
  `email` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: item_add_table
#

DROP TABLE IF EXISTS `item_add_table`;

CREATE TABLE `item_add_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `store` double NOT NULL,
  `cdate` date NOT NULL,
  `note` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (1, 7, 'Cable', '3225', '2', '2020-06-25', 'mixer cable 600 miter');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (2, 2, 'Instruments', '690', '7', '2020-06-25', 'Tp link');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (3, 1, 'Instruments', '1150', '5', '2020-06-25', 'D-link');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (4, 9, 'Instruments', '2', '100', '2020-06-25', '1 packet');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (5, 10, 'Instruments', '30', '15', '2020-06-25', 'Power cable');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (6, 4, 'Instruments', '60', '5', '2020-06-25', 'Tp link');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (7, 6, 'Instruments', '1000', '1', '2020-06-25', 'router 1 antina');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (8, 3, 'Instruments', '80', '3', '2020-06-27', 'Old');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (10, 12, 'Instruments', '60', '6', '2020-06-27', 'Old');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (11, 6, 'Instruments', '1600', '1', '2020-06-30', 'router 3 antina');
INSERT INTO `item_add_table` (`id`, `name`, `type`, `price`, `store`, `cdate`, `note`) VALUES (12, 6, 'Instruments', '1420', '4', '2020-06-30', 'router 2 antina');


#
# TABLE STRUCTURE FOR: item_manage_table
#

DROP TABLE IF EXISTS `item_manage_table`;

CREATE TABLE `item_manage_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `Brand` longtext NOT NULL,
  `type` varchar(100) NOT NULL,
  `in_qty` double NOT NULL,
  `out_qty` double NOT NULL,
  `price` double NOT NULL,
  `store` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (1, 'MC', 'D-link', 'Instruments', '5', '0', '1150', '5');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (2, 'Swich-8port', 'Tp-link', 'Instruments', '7', '0', '690', '7');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (3, 'Pachcore', 'DBC', 'Instruments', '6', '0', '80', '6');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (4, 'TG box', 'D-link', 'Instruments', '5', '0', '60', '5');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (5, 'Microtik', 'Ripon', 'Instruments', '0', '0', '0', '0');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (6, 'Router', 'Tp-link', 'Instruments', '6', '0', '1420', '6');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (7, 'Cat 6', 'ADP', 'Cable', '2', '0', '3225', '2');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (8, 'Cat 5', 'ADP', 'Cable', '0', '0', '0', '0');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (9, 'Connector', 'D-link', 'Instruments', '100', '0', '2', '100');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (10, 'Ac cot', 'D-link', 'Instruments', '15', '0', '30', '15');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (11, 'Router', 'Toto', 'Instruments', '0', '0', '0', '0');
INSERT INTO `item_manage_table` (`id`, `name`, `Brand`, `type`, `in_qty`, `out_qty`, `price`, `store`) VALUES (12, 'Ataptar-mc', 'D-link', 'Instruments', '6', '0', '60', '6');


#
# TABLE STRUCTURE FOR: item_out_table
#

DROP TABLE IF EXISTS `item_out_table`;

CREATE TABLE `item_out_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `store` double NOT NULL,
  `cdate` date NOT NULL,
  `note` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: monthly_report_table
#

DROP TABLE IF EXISTS `monthly_report_table`;

CREATE TABLE `monthly_report_table` (
  `monthly_id` int(11) NOT NULL AUTO_INCREMENT,
  `month_name` int(11) NOT NULL,
  `yearly_name` int(11) NOT NULL,
  `month_running_date` date NOT NULL,
  `dat_total_bill_collection` double NOT NULL,
  `day_total_connection_charge` double NOT NULL,
  `day_total_others_income` double NOT NULL,
  `total_opaning_amount` double NOT NULL,
  `total_opaning_balance` double NOT NULL,
  `day_total_expence` double NOT NULL,
  `day_total_discount` double NOT NULL,
  PRIMARY KEY (`monthly_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (1, 6, 2020, '2020-06-16', '1000', '2800', '0', '0', '1000', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (2, 5, 2020, '2020-05-31', '0', '0', '1000', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (3, 6, 2020, '2020-06-01', '0', '0', '4400', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (4, 6, 2020, '2020-06-07', '0', '0', '4200', '0', '0', '18980', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (5, 6, 2020, '2020-06-09', '0', '0', '1700', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (6, 6, 2020, '2020-06-11', '0', '0', '900', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (7, 6, 2020, '2020-06-12', '0', '0', '2800', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (8, 6, 2020, '2020-06-15', '0', '0', '1800', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (9, 6, 2020, '2020-06-17', '0', '0', '3400', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (10, 6, 2020, '2020-06-18', '0', '0', '1100', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (11, 6, 2020, '2020-06-20', '0', '0', '1500', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (12, 6, 2020, '2020-06-14', '0', '0', '600', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (13, 6, 2020, '2020-06-21', '3000', '200', '15100', '0', '0', '20210', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (14, 6, 2020, '2020-06-22', '1000', '0', '1500', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (15, 6, 2020, '2020-06-27', '0', '0', '0', '0', '0', '20000', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (16, 6, 2020, '2020-06-29', '500', '0', '2000', '0', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (17, 6, 2020, '2020-06-30', '1000', '800', '0', '1000', '0', '0', '0');
INSERT INTO `monthly_report_table` (`monthly_id`, `month_name`, `yearly_name`, `month_running_date`, `dat_total_bill_collection`, `day_total_connection_charge`, `day_total_others_income`, `total_opaning_amount`, `total_opaning_balance`, `day_total_expence`, `day_total_discount`) VALUES (18, 7, 2020, '2020-07-04', '0', '0', '0', '0', '-5890', '0', '0');


#
# TABLE STRUCTURE FOR: occational_customer_sms_table
#

DROP TABLE IF EXISTS `occational_customer_sms_table`;

CREATE TABLE `occational_customer_sms_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `sms_details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `occational_customer_sms_table` (`id`, `sms_details`) VALUES (1, 'Eid Mubarok fdsadsa scdswadwaq asdcsawdsad');


#
# TABLE STRUCTURE FOR: other_income_table
#

DROP TABLE IF EXISTS `other_income_table`;

CREATE TABLE `other_income_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `header_name` int(11) NOT NULL,
  `amount` double NOT NULL,
  `details` longtext NOT NULL,
  `cdate` date NOT NULL,
  `last_update` date NOT NULL,
  `monthly_name` int(11) NOT NULL,
  `yearly_name` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (2, 23, '1000', 'deloyar', '2020-05-31', '2020-06-01', 5, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (3, 24, '4400', 'total bill', '2020-06-01', '2020-06-01', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (5, 24, '3600', 'total bill-net', '2020-06-07', '2020-06-07', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (6, 23, '600', 'tisha-cable bill', '2020-06-07', '2020-06-07', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (7, 24, '1100', 'total bill', '2020-06-09', '2020-06-09', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (8, 23, '600', 'sabbir-cable bill net', '2020-06-09', '2020-06-09', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (9, 24, '900', 'total bill', '2020-06-11', '2020-06-11', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (10, 24, '2400', 'total bill', '2020-06-12', '2020-06-12', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (11, 23, '400', 'net/afol sopon', '2020-06-12', '2020-06-09', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (12, 24, '600', 'total bill', '2020-06-14', '2020-06-12', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (13, 24, '1800', 'total bill', '2020-06-15', '2020-06-15', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (14, 24, '3400', 'total bill', '2020-06-17', '2020-06-17', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (15, 24, '1100', 'total bill', '2020-06-18', '2020-06-18', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (17, 24, '1500', 'total bill-d bank/kalam', '2020-06-20', '2020-06-20', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (18, 23, '500', 'gaffar/sahin', '2020-06-21', '2020-06-21', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (20, 23, '1500', 'kamrul cable ', '2020-06-22', '2020-06-22', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (21, 23, '14600', 'choyon-7600-anik-7000', '2020-06-21', '2020-06-21', 6, 2020);
INSERT INTO `other_income_table` (`id`, `header_name`, `amount`, `details`, `cdate`, `last_update`, `monthly_name`, `yearly_name`) VALUES (22, 24, '2000', 'rakib-Febr-may-june', '2020-06-29', '2020-06-29', 6, 2020);


#
# TABLE STRUCTURE FOR: package_table
#

DROP TABLE IF EXISTS `package_table`;

CREATE TABLE `package_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `Speed` varchar(250) NOT NULL,
  `direct_value` double NOT NULL,
  `amount` double NOT NULL,
  `kb_count` double DEFAULT NULL,
  `status` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (1, 'Mini(600)', '512KBps', '512', '600', '512', 'KBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (2, 'P1(1000)', '1MBps', '1', '1000', '1024', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (3, 'P2(1200)', '1.5MBps', '1.5', '1200', '1536', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (4, 'P3(1400)', '2MBps', '2', '1400', '2048', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (5, 'P4(1600)', '2.5MBps', '2.5', '1600', '2560', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (6, 'MICRO (1800)', '3MBps', '3', '1800', '3072', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (7, 'P6(2000)', '4MBps', '4', '2000', '4096', 'MBps');
INSERT INTO `package_table` (`id`, `name`, `Speed`, `direct_value`, `amount`, `kb_count`, `status`) VALUES (8, 'P7(2200)', '5MBps', '5', '2200', '5120', 'MBps');


#
# TABLE STRUCTURE FOR: payment_table
#

DROP TABLE IF EXISTS `payment_table`;

CREATE TABLE `payment_table` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `due_bill_amount` double NOT NULL,
  `month_name` varchar(100) NOT NULL,
  `payment_date` date NOT NULL,
  `type` varchar(100) NOT NULL,
  `discount` double NOT NULL,
  `amount` double NOT NULL,
  `details` longtext NOT NULL,
  `cdate_time` varchar(1000) NOT NULL,
  `monthly_name` int(11) NOT NULL,
  `yearly_name` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;

INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (1, 41, '0', 'June', '2020-06-25', 'Opaning_amount', '0', '0', 'Running Month Amount', '25/06/2020 11:56:34 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (2, 41, '0', 'June', '2020-06-25', 'Connect_charge', '0', '1800', 'Connect charge', '25/06/2020 11:56:34 am', 0, 0);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (3, 66, '0', 'June', '2020-06-07', 'Opaning_amount', '0', '0', 'Running Month Amount', '07/06/2020 09:03:06 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (4, 66, '0', 'June', '2020-06-07', 'Connect_charge', '0', '1000', 'Connect charge', '07/06/2020 09:03:06 am', 0, 0);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (5, 76, '0', 'June', '2020-06-21', 'Connect_charge', '0', '200', 'Connect charge', '21/06/2020 08:57:58 am', 0, 0);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (6, 41, '0', 'June', '2020-06-21', 'Monthly', '0', '1000', 'Dish Bill Monthly', '21/06/2020 10:13:43 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (8, 36, '600', 'June', '2020-06-22', 'Monthly', '0', '600', 'Dish Bill Monthly', '22/06/2020 09:28:01 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (9, 36, '200', 'June', '2020-06-22', 'Pre_due', '0', '400', 'Dish Bill Monthly', '22/06/2020 09:28:25 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (10, 76, '0', 'June', '2020-06-21', 'Monthly', '0', '500', 'Dish Bill Monthly', '21/06/2020 11:58:00 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (11, 19, '600', 'June', '2020-06-21', 'Monthly', '0', '500', 'Dish Bill Monthly', '21/06/2020 11:58:48 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (12, 19, '100', 'May', '2020-06-21', 'Pre_due', '0', '500', 'Dish Bill Monthly', '21/06/2020 11:59:15 am', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (13, 14, '1300', 'June', '2020-06-21', 'Pre_due', '0', '500', 'Dish Bill Monthly', '21/06/2020 12:00:26 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (14, 60, '0', 'June', '2020-06-21', 'Monthly', '0', '500', 'Dish Bill Monthly', '21/06/2020 12:01:23 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (15, 62, '0', 'June', '2020-06-21', 'Monthly', '0', '500', 'Dish Bill Monthly', '21/06/2020 12:01:53 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (17, 26, '0', 'June', '2020-06-29', 'Monthly', '0', '500', 'Dish Bill Monthly', '29/06/2020 04:01:03 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (18, 16, '200', 'June', '2020-06-30', 'Pre_due', '0', '1000', 'Dish Bill Monthly', '30/06/2020 09:13:28 pm', 6, 2020);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (20, 78, '0', 'June', '2020-06-30', 'Opaning_amount', '0', '500', 'Running Month Amount', '30/06/2020 09:18:18 pm', 0, 0);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (21, 78, '0', 'June', '2020-06-30', 'Connect_charge', '0', '800', 'Connect charge', '30/06/2020 09:18:18 pm', 0, 0);
INSERT INTO `payment_table` (`payment_id`, `customer_id`, `due_bill_amount`, `month_name`, `payment_date`, `type`, `discount`, `amount`, `details`, `cdate_time`, `monthly_name`, `yearly_name`) VALUES (22, 79, '0', 'June', '2020-06-30', 'Opaning_amount', '0', '500', 'Connect charge', '30/06/2020 09:23:23 pm', 0, 0);


#
# TABLE STRUCTURE FOR: pre_customer_report_table
#

DROP TABLE IF EXISTS `pre_customer_report_table`;

CREATE TABLE `pre_customer_report_table` (
  `pre_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` double NOT NULL,
  `details` longtext NOT NULL,
  PRIMARY KEY (`pre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (1, 1, '2020-06-23', '1000', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (2, 2, '2020-06-23', '1000', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (3, 3, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (4, 4, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (5, 5, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (6, 6, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (7, 7, '2020-06-23', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (8, 8, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (9, 9, '2020-06-23', '1800', 'march-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (10, 10, '2020-06-23', '1200', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (11, 11, '2020-06-23', '1200', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (12, 12, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (13, 13, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (14, 14, '2020-06-23', '1800', 'march-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (15, 15, '2020-06-23', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (16, 16, '2020-06-23', '1200', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (17, 17, '2020-06-23', '1200', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (18, 18, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (19, 19, '2020-06-23', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (20, 20, '2020-06-23', '800', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (21, 21, '2020-06-23', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (22, 22, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (23, 23, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (24, 23, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (25, 24, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (26, 25, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (27, 26, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (28, 27, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (29, 28, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (30, 29, '2020-06-24', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (31, 30, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (32, 31, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (33, 32, '2020-06-24', '700', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (34, 33, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (35, 34, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (36, 35, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (37, 35, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (38, 36, '2020-06-24', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (39, 37, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (40, 38, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (41, 39, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (42, 40, '2020-06-24', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (43, 41, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (44, 42, '2020-06-24', '2000', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (45, 43, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (46, 44, '2020-06-24', '600', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (47, 45, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (48, 46, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (49, 43, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (50, 47, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (51, 48, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (52, 49, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (53, 50, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (54, 51, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (55, 52, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (56, 53, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (57, 52, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (58, 54, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (59, 55, '2020-06-24', '2400', 'Feb-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (60, 56, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (61, 57, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (62, 58, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (63, 59, '2020-06-24', '500', 'june');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (64, 60, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (65, 61, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (66, 62, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (67, 63, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (68, 64, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (69, 65, '2020-06-24', '1200', 'april-may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (70, 66, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (71, 67, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (72, 68, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (73, 69, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (74, 70, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (75, 71, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (76, 72, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (77, 73, '2020-06-24', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (78, 74, '2020-06-25', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (79, 75, '2020-06-27', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (80, 76, '2020-06-21', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (81, 76, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (82, 62, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (83, 19, '2020-06-30', '0', 'may-2020');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (84, 60, '2020-06-21', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (85, 26, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (86, 77, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (87, 78, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (88, 79, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (89, 80, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (90, 81, '2020-06-30', '0', '');
INSERT INTO `pre_customer_report_table` (`pre_id`, `customer_id`, `payment_date`, `amount`, `details`) VALUES (91, 82, '2020-07-04', '0', '');


#
# TABLE STRUCTURE FOR: remarks_table
#

DROP TABLE IF EXISTS `remarks_table`;

CREATE TABLE `remarks_table` (
  `remarks_id` int(1) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `cdate_time` varchar(1000) NOT NULL,
  `comments` longtext NOT NULL,
  PRIMARY KEY (`remarks_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: superadmin
#

DROP TABLE IF EXISTS `superadmin`;

CREATE TABLE `superadmin` (
  `id` int(111) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(111) CHARACTER SET utf8 NOT NULL,
  `password` varchar(111) CHARACTER SET utf8 NOT NULL,
  `companyname` varchar(111) NOT NULL,
  `title` longtext NOT NULL,
  `address` longtext NOT NULL,
  `company_mobile` varchar(111) NOT NULL,
  `com_email` varchar(99) NOT NULL,
  `type` varchar(10) NOT NULL,
  `logo_image` longtext,
  `sms_cname` longtext NOT NULL,
  `sms_user` longtext NOT NULL,
  `sms_password` longtext NOT NULL,
  `sms_sender` varchar(100) NOT NULL,
  `support_num` varchar(100) NOT NULL,
  `excel_company_name` longtext NOT NULL,
  `excel_company_title` longtext NOT NULL,
  `excel_company_keyword` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `superadmin` (`id`, `UserId`, `password`, `companyname`, `title`, `address`, `company_mobile`, `com_email`, `type`, `logo_image`, `sms_cname`, `sms_user`, `sms_password`, `sms_sender`, `support_num`, `excel_company_name`, `excel_company_title`, `excel_company_keyword`) VALUES (1, 'superadmin', '17c4520f6cfd1ab53d8745e84681eb49', 'Meghnalink.com', 'Meghnalink.com', 'Mohammadpure,luterchar,meghna,comilla-3516', '01854238062', 'meghnalinkdotcom@gmail.com', 'Superadmin', '1592650964.png', 'xzzX', 'zxZX', 'zXzX', '243234', '234234234', 'rrrr', 'rrr', 'CCL');


#
# TABLE STRUCTURE FOR: village_table
#

DROP TABLE IF EXISTS `village_table`;

CREATE TABLE `village_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `village_table` (`id`, `name`) VALUES (2, 'Noya Mohammadpure');
INSERT INTO `village_table` (`id`, `name`) VALUES (3, 'Mohammadpur');
INSERT INTO `village_table` (`id`, `name`) VALUES (4, 'Sonapure');
INSERT INTO `village_table` (`id`, `name`) VALUES (5, 'Luterchar');
INSERT INTO `village_table` (`id`, `name`) VALUES (6, 'Dhori luterchar');
INSERT INTO `village_table` (`id`, `name`) VALUES (7, 'Kandargao');
INSERT INTO `village_table` (`id`, `name`) VALUES (8, 'Noya kandargao');
INSERT INTO `village_table` (`id`, `name`) VALUES (9, 'Abdullah pure');
INSERT INTO `village_table` (`id`, `name`) VALUES (10, 'Sekher gao');
INSERT INTO `village_table` (`id`, `name`) VALUES (15, 'Luterchar chok');


#
# TABLE STRUCTURE FOR: zone_table
#

DROP TABLE IF EXISTS `zone_table`;

CREATE TABLE `zone_table` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `zoneName` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (1, 'razib');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (2, 'mpure stand');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (3, 'KN stand');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (4, 'Ujjol bari');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (5, 'Emran');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (6, 'Arif');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (7, 'Mosjid');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (8, 'Lc-bazar');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (9, 'Orola khamba');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (10, 'Rubel bari');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (11, 'Jakariya');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (14, 'Gaffar bari');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (15, 'Sahalom bari');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (16, 'High school');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (17, 'R-cheyarman');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (18, 'Choyon');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (19, 'Azizul');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (20, 'Kadir bari');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (21, 'Free zone');
INSERT INTO `zone_table` (`id`, `zoneName`) VALUES (22, 'Office zone');


